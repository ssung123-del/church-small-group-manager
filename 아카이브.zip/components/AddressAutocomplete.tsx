import React, { useEffect, useRef } from 'react';

interface Props {
  value: string;
  onChange: (value: string) => void;
  onPlaceSelected?: (address: string) => void;
  placeholder?: string;
  className?: string;
}

const AddressAutocomplete: React.FC<Props> = ({ value, onChange, onPlaceSelected, placeholder, className }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const autocompleteRef = useRef<any>(null);

  useEffect(() => {
    if (!inputRef.current || !window.google || !window.google.maps || !window.google.maps.places) return;

    autocompleteRef.current = new window.google.maps.places.Autocomplete(inputRef.current, {
      types: ['geocode'], // Address types
      componentRestrictions: { country: 'kr' }, // Limit to Korea
      fields: ['formatted_address', 'geometry']
    });

    autocompleteRef.current.addListener('place_changed', () => {
      const place = autocompleteRef.current?.getPlace();
      if (place && place.formatted_address) {
        // Remove "South Korea" or "대한민국" prefix if cleaner output is desired, 
        // but Google's formatted_address is usually fine.
        let address = place.formatted_address;
        
        // Optional: simple cleanup
        address = address.replace(/^대한민국\s+/, ''); 

        onChange(address);
        if (onPlaceSelected) {
          onPlaceSelected(address);
        }
      }
    });
  }, [onPlaceSelected, onChange]);

  return (
    <input
      ref={inputRef}
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder || "주소를 입력하세요"}
      className={className}
    />
  );
};

export default AddressAutocomplete;