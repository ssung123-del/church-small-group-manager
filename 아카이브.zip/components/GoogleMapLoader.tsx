import React, { useEffect, useState } from 'react';
import { GOOGLE_MAPS_API_KEY } from '../constants';

interface Props {
  onLoad: () => void;
  children?: React.ReactNode;
}

const GoogleMapLoader: React.FC<Props> = ({ onLoad, children }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState<React.ReactNode | null>(null);

  useEffect(() => {
    // 1. Check if key is missing
    if (!GOOGLE_MAPS_API_KEY || GOOGLE_MAPS_API_KEY.includes('YOUR_')) {
      setError("Google Maps API Key가 설정되지 않았습니다. constants.ts 파일을 확인해주세요.");
      return;
    }

    // 2. Define global auth failure handler
    // This function is called by Google Maps API script automatically when auth fails
    window.gm_authFailure = () => {
      console.error("Google Maps Auth Failure");
      const currentUrl = window.location.href;
      const currentOrigin = window.location.origin;
      
      setError(
        <div className="text-left space-y-3">
          <div>
            <p className="font-bold text-red-700">Google Maps 인증 실패 (RefererNotAllowedMapError)</p>
            <p className="text-sm text-red-600">Google Cloud Console의 API 키 설정에서 현재 웹사이트 주소가 허용되지 않았습니다.</p>
          </div>
          
          <div className="bg-white p-3 rounded border border-red-200 text-sm">
            <p className="mb-1 font-semibold text-gray-700">해결 방법:</p>
            <ol className="list-decimal list-inside space-y-1 text-gray-600">
              <li><a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noreferrer" className="text-blue-600 underline">Google Cloud Console</a> 접속</li>
              <li>사용 중인 API Key 선택</li>
              <li>'애플리케이션 제한사항' &gt; '웹사이트' 확인</li>
              <li>'웹사이트 제한사항'에 아래 <strong>두 주소</strong>를 모두 추가:</li>
            </ol>
            <div className="mt-2 space-y-2">
              <code className="block bg-gray-100 p-2 rounded select-all font-mono text-blue-700 break-all border border-gray-200">
                {currentOrigin}/*
              </code>
              <code className="block bg-gray-100 p-2 rounded select-all font-mono text-blue-700 break-all border border-gray-200">
                {currentUrl}
              </code>
            </div>
            <p className="mt-2 text-xs text-gray-500">
              * 변경 후 반영까지 최대 5분이 소요될 수 있습니다.
            </p>
          </div>
          
          <button 
            onClick={() => window.location.reload()}
            className="w-full bg-red-100 hover:bg-red-200 text-red-800 font-semibold py-2 px-4 rounded transition-colors"
          >
            설정 변경 후 새로고침
          </button>
        </div>
      );
    };

    // 3. Check if script is already loaded/loading
    const scriptId = 'google-maps-script';
    if (document.getElementById(scriptId)) {
      if (window.google && window.google.maps) {
        setIsLoaded(true);
        onLoad();
      } else {
        // Script exists but maybe not fully loaded or failed. 
        // We can attach a listener or poll, but simplest is to wait a bit.
        // If it failed auth, gm_authFailure should have fired or will fire.
        const checkInterval = setInterval(() => {
            if (window.google && window.google.maps) {
                clearInterval(checkInterval);
                setIsLoaded(true);
                onLoad();
            }
        }, 500);
        
        // Timeout after 10s
        setTimeout(() => clearInterval(checkInterval), 10000);
      }
      return;
    }

    // 4. Inject Script
    const script = document.createElement('script');
    script.id = scriptId;
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places`;
    script.async = true;
    script.defer = true;
    
    script.onload = () => {
      setTimeout(() => {
          setIsLoaded(true);
          onLoad();
      }, 100);
    };

    script.onerror = () => {
      setError("Google Maps 스크립트 로드에 실패했습니다. 네트워크 차단 여부를 확인하세요.");
    };

    document.head.appendChild(script);

  }, [onLoad]);

  if (error) {
    return (
      <div className="bg-red-50 p-6 rounded-lg border border-red-200 m-4 flex flex-col items-center justify-center min-h-[300px]">
        <svg className="w-12 h-12 text-red-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
        <div className="w-full max-w-lg">
          {error}
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default GoogleMapLoader;