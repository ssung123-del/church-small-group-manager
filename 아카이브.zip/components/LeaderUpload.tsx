import React, { useState, useEffect } from 'react';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { geocodeAddress, sleep } from '../services/geoService';
import { insertLeader, fetchLeaders, deleteLeader, fetchFullData, insertMember } from '../services/googleSheetService';
import { Leader } from '../types';
import { GEOCODE_DELAY_MS } from '../constants';
import AddressAutocomplete from './AddressAutocomplete';
import MemberManagementModal from './MemberManagementModal';

const LeaderUpload: React.FC = () => {
  // Main Tab State: 'LEADER' or 'MEMBER'
  const [dataScope, setDataScope] = useState<'LEADER' | 'MEMBER'>('LEADER');
  
  // Input Mode: 'csv' or 'manual'
  const [mode, setMode] = useState<'csv' | 'manual'>('csv');
  
  const [leaders, setLeaders] = useState<Leader[]>([]);
  const [processing, setProcessing] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [progress, setProgress] = useState(0);

  // Manual Forms
  const [leaderForm, setLeaderForm] = useState<any>({
    name: '', role: '집사', gender: 'Male', age: '', contact: '', address: '', max_capacity: 10
  });
  const [memberForm, setMemberForm] = useState<any>({
    name: '', role: '성도', gender: 'Male', age: '', contact: '', address: '', leader_id: ''
  });

  const [manualLoading, setManualLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  // Modal State
  const [selectedLeader, setSelectedLeader] = useState<Leader | null>(null);

  useEffect(() => { loadLeaders(); }, []);

  const loadLeaders = async () => {
    try { setLeaders(await fetchLeaders()); } catch (err) { console.error(err); }
  };

  const addLog = (msg: string) => setLogs(prev => [msg, ...prev]);

  // --- DOWNLOAD SAMPLE CSV ---
  const handleDownloadSample = () => {
    const isLeader = dataScope === 'LEADER';
    // BOM for Excel Korean support (\uFEFF)
    let csvContent = "\uFEFF";
    
    if (isLeader) {
      csvContent += "name,role,gender,age,contact,address,max_capacity\n";
      csvContent += "홍길동,집사,Male,40,010-1234-5678,서울시 강남구 테헤란로 123,10\n";
      csvContent += "이영희,권사,Female,55,010-9876-5432,서울시 서초구 서초대로 456,12";
    } else {
      csvContent += "name,role,age,contact,address,leader_name\n";
      csvContent += "김철수,성도,35,010-1111-2222,경기도 성남시 분당구 판교로 123,홍길동\n";
      csvContent += "박민수,성도,42,010-3333-4444,서울시 송파구 올림픽로 789,"; // leader_name 비어있으면 미배정
    }

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${isLeader ? '리더' : '순원'}_등록_샘플.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // --- CSV UPLOAD HANDLER ---
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setProcessing(true);
    setLogs([]);
    setProgress(0);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (h) => h.trim(),
      complete: async (results: any) => {
        const rows = results.data;
        addLog(`총 ${rows.length}개 데이터 분석 시작... (${dataScope} 모드)`);
        
        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          
          // Basic Validation
          if (!row.name || !row.address) {
             addLog(`[SKIP] ${i+1}행: 필수 정보 누락 (이름/주소 확인)`);
             continue;
          }

          try {
            // Geocoding
            const geo = await geocodeAddress(row.address);
            
            if (dataScope === 'LEADER') {
              // --- LEADER REGISTRATION ---
              const newLeader: Leader = {
                name: row.name,
                role: row.role || '성도',
                gender: row.gender || 'Male',
                age: parseInt(row.age) || 40,
                contact: row.contact || '',
                address: geo.formattedAddress, 
                lat: geo.lat,
                lng: geo.lng,
                max_capacity: parseInt(row.max_capacity) || 10,
                current_members: 0
              };
              await insertLeader(newLeader);
              addLog(`[OK] 리더 '${row.name}' 등록 완료`);
            
            } else {
              // --- MEMBER REGISTRATION ---
              // Find Leader by Name (if provided)
              let matchedLeaderId: number | null = null;
              if (row.leader_name) {
                const matchedLeader = leaders.find(l => l.name === row.leader_name);
                if (matchedLeader && matchedLeader.id) {
                  matchedLeaderId = matchedLeader.id;
                } else {
                  addLog(`[WARN] '${row.name}'의 리더 '${row.leader_name}'를 찾을 수 없어 미배정 처리합니다.`);
                }
              }

              await insertMember({
                name: row.name,
                role: row.role || '성도',
                age: parseInt(row.age) || 40,
                contact: row.contact || '',
                address: geo.formattedAddress,
                lat: geo.lat,
                lng: geo.lng,
                leader_id: matchedLeaderId,
                // gender is not in Member table schema currently, handled as generic or add if needed
              });
              
              const status = matchedLeaderId ? `배정 완료` : `미배정 등록`;
              addLog(`[OK] 순원 '${row.name}' ${status}`);
            }

          } catch (err: any) {
            addLog(`[ERR] ${row.name}: ${err.message}`);
          }

          // Delay for API Limit
          setProgress(Math.round(((i + 1) / rows.length) * 100));
          await sleep(GEOCODE_DELAY_MS);
        }
        
        setProcessing(false);
        loadLeaders(); // Refresh list to update counts
        e.target.value = '';
      }
    });
  };

  // --- MANUAL SUBMIT HANDLER ---
  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setManualLoading(true);
    try {
      if (dataScope === 'LEADER') {
        const geo = await geocodeAddress(leaderForm.address);
        await insertLeader({
          ...leaderForm,
          age: parseInt(leaderForm.age),
          max_capacity: parseInt(leaderForm.max_capacity),
          lat: geo.lat,
          lng: geo.lng,
          current_members: 0
        } as Leader);
        alert("리더가 등록되었습니다.");
        setLeaderForm({ name: '', role: '집사', gender: 'Male', age: '', contact: '', address: '', max_capacity: 10 });
      } else {
        const geo = await geocodeAddress(memberForm.address);
        await insertMember({
          ...memberForm,
          age: parseInt(memberForm.age),
          lat: geo.lat,
          lng: geo.lng,
          leader_id: memberForm.leader_id ? parseInt(memberForm.leader_id) : null
        });
        alert("순원이 등록되었습니다.");
        setMemberForm({ name: '', role: '성도', gender: 'Male', age: '', contact: '', address: '', leader_id: '' });
      }
      
      loadLeaders();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setManualLoading(false);
    }
  };

  const handleDelete = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if(!confirm("삭제하시겠습니까? 연결된 소그룹원 정보가 해제됩니다.")) return;
    setDeletingId(id);
    try {
      await deleteLeader(id);
      await loadLeaders();
    } catch(err) { alert(err); } 
    finally { setDeletingId(null); }
  };

  const handleExport = async () => {
    try {
      const { leaders, members } = await fetchFullData();
      
      const exportData: any[] = [];
      
      leaders.forEach(leader => {
         const leaderMembers = members.filter(m => m.leader_id === leader.id);
         
         if (leaderMembers.length === 0) {
             exportData.push({
                 '리더 이름': leader.name,
                 '리더 직분': leader.role,
                 '리더 연락처': leader.contact,
                 '리더 주소': leader.address,
                 '소그룹원 이름': '(배정 없음)',
                 '소그룹원 직분': '',
                 '소그룹원 주소': ''
             });
         } else {
             leaderMembers.forEach(m => {
                 exportData.push({
                    '리더 이름': leader.name,
                    '리더 직분': leader.role,
                    '리더 연락처': leader.contact,
                    '리더 주소': leader.address,
                    '소그룹원 이름': m.name,
                    '소그룹원 직분': m.role,
                    '소그룹원 주소': m.address
                 });
             });
         }
      });

      const unassigned = members.filter(m => m.leader_id === null);
      unassigned.forEach(m => {
          exportData.push({
             '리더 이름': '(미배정)',
             '리더 직분': '',
             '리더 연락처': '',
             '리더 주소': '',
             '소그룹원 이름': m.name,
             '소그룹원 직분': m.role,
             '소그룹원 주소': m.address
          });
      });

      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(exportData);
      ws['!cols'] = [{wch:10}, {wch:10}, {wch:15}, {wch:30}, {wch:10}, {wch:10}, {wch:30}];
      XLSX.utils.book_append_sheet(wb, ws, "소그룹 편성표");
      XLSX.writeFile(wb, `소그룹_편성_결과_${new Date().toISOString().slice(0,10)}.xlsx`);

    } catch(err: any) {
        alert("내보내기 실패: " + err.message);
    }
  };

  const inputClass = "block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 sm:text-sm py-2 px-3 border";

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-12 relative">
      
      {/* Modal */}
      {selectedLeader && (
        <MemberManagementModal 
          leader={selectedLeader} 
          onClose={() => setSelectedLeader(null)} 
          onUpdate={loadLeaders} 
        />
      )}

      {/* LEFT COLUMN: Actions */}
      <div className="lg:col-span-1 space-y-6">
        
        {/* DATA SCOPE TABS (Leader vs Member) */}
        <div className="bg-slate-100 p-1 rounded-xl flex shadow-inner">
           <button 
             onClick={() => setDataScope('LEADER')} 
             className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${dataScope === 'LEADER' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
           >
             리더 등록 관리
           </button>
           <button 
             onClick={() => setDataScope('MEMBER')} 
             className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${dataScope === 'MEMBER' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
           >
             순원 등록 관리
           </button>
        </div>

        {/* Action Toggle Panel */}
        <div className="bg-white p-1 rounded-xl shadow-sm border border-slate-200 flex">
          <button onClick={() => setMode('csv')} className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all ${mode === 'csv' ? 'bg-brand-50 text-brand-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>CSV 일괄 등록</button>
          <button onClick={() => setMode('manual')} className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all ${mode === 'manual' ? 'bg-brand-50 text-brand-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>직접 입력</button>
        </div>

        {mode === 'csv' ? (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-6">
            <div className="text-center space-y-2">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto ${dataScope === 'LEADER' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'}`}>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
              </div>
              <h3 className="font-bold text-slate-800">{dataScope === 'LEADER' ? '리더' : '순원'} CSV 업로드</h3>
              <p className="text-sm text-slate-500">
                {dataScope === 'LEADER' 
                  ? "리더 명단을 일괄 등록합니다." 
                  : "순원 명단을 등록합니다. 'leader_name' 컬럼이 있으면 자동 매칭됩니다."}
              </p>
              
              {/* Added Download Sample Button */}
              <button 
                onClick={handleDownloadSample}
                className="text-xs font-semibold text-brand-600 bg-brand-50 hover:bg-brand-100 px-3 py-1.5 rounded-full inline-flex items-center gap-1 transition-colors mt-2"
              >
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                샘플 양식 다운로드
              </button>

              {dataScope === 'MEMBER' && (
                  <p className="text-xs text-slate-400 bg-slate-50 px-2 py-1 rounded inline-block mt-2">
                      * leader_name이 비어있으면 미배정 상태로 등록됩니다.
                  </p>
              )}
            </div>

            <label className={`block w-full border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all group ${processing ? 'border-slate-300 bg-slate-50' : 'border-brand-200 hover:border-brand-400 hover:bg-brand-50'}`}>
              <input type="file" accept=".csv" disabled={processing} onChange={handleFileUpload} className="hidden" />
              <div className="space-y-1">
                <p className="text-sm font-medium text-brand-600 group-hover:text-brand-700">파일 선택하기</p>
                <p className="text-xs text-slate-400">CSV (쉼표 분리) 형식</p>
              </div>
            </label>

            {processing && (
              <div className="space-y-2">
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-brand-500 transition-all duration-300" style={{ width: `${progress}%` }}></div>
                </div>
                <p className="text-xs text-center text-slate-500 font-mono">{progress}% 처리 중...</p>
              </div>
            )}

            <div className="h-48 bg-slate-900 rounded-lg p-3 overflow-y-auto font-mono text-xs text-green-400 shadow-inner">
              {logs.length ? logs.map((l, i) => <div key={i}>{l}</div>) : <span className="text-slate-600 opacity-50">대기 중...</span>}
            </div>
          </div>
        ) : (
          <form onSubmit={handleManualSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
            <h3 className="font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2">새 {dataScope === 'LEADER' ? '리더' : '순원'} 정보</h3>
            
            {dataScope === 'LEADER' ? (
              <>
                <input type="text" required value={leaderForm.name} onChange={e => setLeaderForm({...leaderForm, name: e.target.value})} className={inputClass} placeholder="리더 이름" />
                <AddressAutocomplete 
                   value={leaderForm.address} 
                   onChange={v => setLeaderForm({...leaderForm, address: v})} 
                   placeholder="주소 검색"
                   className={inputClass}
                />
                <div className="grid grid-cols-2 gap-3">
                   <input type="number" required value={leaderForm.age} onChange={e => setLeaderForm({...leaderForm, age: e.target.value})} className={inputClass} placeholder="나이" />
                   <select value={leaderForm.gender} onChange={e => setLeaderForm({...leaderForm, gender: e.target.value})} className={inputClass}>
                     <option value="Male">남성</option>
                     <option value="Female">여성</option>
                   </select>
                </div>
                <input type="text" value={leaderForm.role} onChange={e => setLeaderForm({...leaderForm, role: e.target.value})} className={inputClass} placeholder="직분 (예: 집사)" />
              </>
            ) : (
              <>
                <input type="text" required value={memberForm.name} onChange={e => setMemberForm({...memberForm, name: e.target.value})} className={inputClass} placeholder="순원 이름" />
                <AddressAutocomplete 
                   value={memberForm.address} 
                   onChange={v => setMemberForm({...memberForm, address: v})} 
                   placeholder="주소 검색"
                   className={inputClass}
                />
                <div className="grid grid-cols-2 gap-3">
                   <input type="number" required value={memberForm.age} onChange={e => setMemberForm({...memberForm, age: e.target.value})} className={inputClass} placeholder="나이" />
                   <input type="text" value={memberForm.role} onChange={e => setMemberForm({...memberForm, role: e.target.value})} className={inputClass} placeholder="직분" />
                </div>
                <div>
                   <label className="text-xs text-slate-500 font-bold block mb-1">배정할 리더 (선택)</label>
                   <select 
                      value={memberForm.leader_id} 
                      onChange={e => setMemberForm({...memberForm, leader_id: e.target.value})} 
                      className={inputClass}
                   >
                     <option value="">미배정</option>
                     {leaders.map(l => (
                       <option key={l.id} value={l.id}>{l.name} ({l.current_members}/{l.max_capacity})</option>
                     ))}
                   </select>
                </div>
              </>
            )}

            <button type="submit" disabled={manualLoading} className="w-full bg-brand-600 text-white font-bold py-2.5 rounded-lg shadow-sm hover:bg-brand-700 transition-all">
              {manualLoading ? '저장 중...' : '등록하기'}
            </button>
          </form>
        )}
      </div>

      {/* RIGHT COLUMN: List */}
      <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col overflow-hidden h-[600px] lg:h-auto">
        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <h2 className="font-bold text-slate-800">등록 리더 현황 <span className="text-brand-600 ml-1">{leaders.length}</span></h2>
          <div className="flex gap-2">
            <button 
                onClick={handleExport}
                className="text-xs font-bold text-green-700 bg-green-50 hover:bg-green-100 border border-green-200 px-3 py-1.5 rounded flex items-center gap-1 transition-colors"
            >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                엑셀 내보내기
            </button>
            <button onClick={loadLeaders} className="text-xs font-medium text-slate-500 hover:text-brand-600 flex items-center gap-1 bg-white px-2 py-1 rounded border shadow-sm">
                 새로고침
            </button>
          </div>
        </div>
        
        <div className="flex-1 overflow-auto bg-white">
          
          {/* Mobile View: Stacked Cards */}
          <div className="block sm:hidden divide-y divide-slate-100">
             {leaders.length === 0 ? (
               <div className="p-8 text-center text-slate-400">데이터가 없습니다.</div>
             ) : leaders.map(leader => (
               <div key={leader.id} onClick={() => setSelectedLeader(leader)} className="p-4 flex flex-col gap-2.5 active:bg-slate-50">
                 {/* Row 1: Name, Role, Age/Gender, Capacity, Delete */}
                 <div className="flex justify-between items-start">
                   <div className="flex flex-wrap items-baseline gap-x-2">
                     <span className="font-bold text-slate-900 text-lg">{leader.name}</span>
                     <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">{leader.role}</span>
                     <span className="text-xs text-slate-400">{leader.age}세 · {leader.gender === 'Male' ? '남' : '여'}</span>
                   </div>
                   
                   <div className="flex items-center gap-2 pl-2">
                     <span className={`text-xs font-bold px-2 py-1 rounded-full whitespace-nowrap ${leader.current_members >= leader.max_capacity ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                       {leader.current_members}/{leader.max_capacity}명
                     </span>
                     <button 
                       onClick={(e) => leader.id && handleDelete(leader.id, e)} 
                       className={`p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors ${deletingId === leader.id ? 'opacity-50' : ''}`}
                     >
                       <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                     </button>
                   </div>
                 </div>

                 {/* Row 2: Contact */}
                 {leader.contact && (
                   <div className="flex items-center gap-2 text-sm text-slate-600">
                     <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                     <span className="font-medium">{leader.contact}</span>
                   </div>
                 )}

                 {/* Row 3: Address */}
                 <div className="flex items-start gap-2 text-sm text-slate-500">
                    <svg className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                    <span className="break-keep leading-snug">{leader.address}</span>
                 </div>
               </div>
             ))}
          </div>

          {/* Desktop View: Table */}
          <table className="hidden sm:table w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 sticky top-0 z-10 text-xs uppercase font-semibold text-slate-500">
              <tr>
                <th className="px-6 py-3 border-b">리더 정보</th>
                <th className="px-6 py-3 border-b">주소 / 연락처</th>
                <th className="px-6 py-3 border-b text-center">정원</th>
                <th className="px-6 py-3 border-b text-right">관리</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {leaders.length === 0 ? (
                <tr><td colSpan={4} className="p-8 text-center text-slate-400">데이터가 없습니다.</td></tr>
              ) : leaders.map(leader => (
                <tr key={leader.id} onClick={() => setSelectedLeader(leader)} className="hover:bg-slate-50/80 transition-colors group cursor-pointer">
                  <td className="px-6 py-3.5">
                    <div className="font-bold text-slate-900 group-hover:text-brand-600 transition-colors">{leader.name} <span className="font-normal text-xs text-slate-500 ml-1">({leader.role})</span></div>
                    <div className="text-xs text-slate-400">{leader.gender} · {leader.age}세</div>
                  </td>
                  <td className="px-6 py-3.5 max-w-[200px]">
                    <div className="truncate text-slate-700" title={leader.address}>{leader.address}</div>
                    <div className="text-xs text-slate-400">{leader.contact || '-'}</div>
                  </td>
                  <td className="px-6 py-3.5 text-center">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${leader.current_members >= leader.max_capacity ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}`}>
                      {leader.current_members}/{leader.max_capacity}
                    </span>
                  </td>
                  <td className="px-6 py-3.5 text-right">
                    <button 
                      onClick={(e) => leader.id && handleDelete(leader.id, e)} 
                      className={`text-slate-400 hover:text-red-600 p-1 rounded hover:bg-red-50 transition-colors ${deletingId === leader.id ? 'opacity-50' : ''}`}
                      title="삭제"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default LeaderUpload;