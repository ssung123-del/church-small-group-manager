import React, { useState } from 'react';
import { checkConnection } from '../services/googleSheetService';
import { SHEET_API_URL_KEY } from '../constants';

interface Props {
  onComplete: () => void;
}

const GAS_SCRIPT_CODE = `
// 1. 이 코드를 Apps Script 에디터에 붙여넣으세요.
// 2. '배포' > '새 배포' > 유형 선택: '웹 앱'
// 3. 실행 권한: '나(Me)', 액세스 권한: '모든 사용자(Anyone)' 선택 후 배포
// 4. 생성된 '웹 앱 URL'을 복사하여 앱에 입력하세요.

function doPost(e) {
  const lock = LockService.getScriptLock();
  // 동시 접속 충돌 방지를 위해 30초간 락 대기
  lock.tryLock(30000);
  
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet();
    const request = JSON.parse(e.postData.contents);
    const action = request.action;
    let data = null;

    initSheets(sheet);

    if (action === 'PING') {
      data = 'PONG';
    } else if (action === 'GET_LEADERS') {
      // 리더 목록 조회 시, 최신 멤버 수를 강제로 다시 계산하여 정확도 유지
      refreshAllLeaderCounts(sheet);
      data = getLeaders(sheet);
    } else if (action === 'ADD_LEADER') {
      data = addLeader(sheet, request.leader);
    } else if (action === 'DELETE_LEADER') {
      data = deleteLeader(sheet, request.id);
    } else if (action === 'ADD_MEMBER') {
      data = addMember(sheet, request.member);
    } else if (action === 'GET_MEMBERS_BY_LEADER') {
      data = getMembersByLeader(sheet, request.leaderId);
    } else if (action === 'GET_ALL_MEMBERS') {
      data = getAllMembers(sheet);
    } else if (action === 'REMOVE_MEMBER') {
      data = removeMember(sheet, request.memberId, request.leaderId, request.mode);
    }

    return ContentService.createTextOutput(JSON.stringify({ status: 'success', data: data }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}

// 초기 시트 생성
function initSheets(ss) {
  if (!ss.getSheetByName("Leaders")) {
    const s = ss.insertSheet("Leaders");
    s.appendRow(["id", "name", "role", "gender", "age", "contact", "address", "lat", "lng", "max_capacity", "current_members"]);
  }
  if (!ss.getSheetByName("Members")) {
    const s = ss.insertSheet("Members");
    s.appendRow(["id", "leader_id", "name", "role", "age", "contact", "address", "lat", "lng"]);
  }
}

function getRows(sheetName) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  const data = sheet.getDataRange().getValues();
  const headers = data.shift();
  return data.map(row => {
    let obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
}

function getLeaders(ss) {
  return getRows("Leaders");
}

function addLeader(ss, leader) {
  const sheet = ss.getSheetByName("Leaders");
  const id = new Date().getTime(); // Simple ID
  sheet.appendRow([
    id, leader.name, leader.role, leader.gender, leader.age, leader.contact, leader.address, 
    leader.lat, leader.lng, leader.max_capacity, 0
  ]);
  return "OK";
}

function deleteLeader(ss, id) {
  const mSheet = ss.getSheetByName("Members");
  const mData = mSheet.getDataRange().getValues();
  
  // 리더 삭제 시 해당 소그룹원들을 '미배정(빈값)' 처리
  // Members Sheet Header: id(0), leader_id(1)
  for (let i = 1; i < mData.length; i++) {
    if (String(mData[i][1]) === String(id)) {
      mSheet.getRange(i + 1, 2).setValue(""); 
    }
  }

  const sheet = ss.getSheetByName("Leaders");
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(id)) {
      sheet.deleteRow(i + 1);
      break;
    }
  }
  return "OK";
}

function addMember(ss, member) {
  const sheet = ss.getSheetByName("Members");
  const id = new Date().getTime();
  sheet.appendRow([
    id, member.leader_id || "", member.name, member.role, member.age, member.contact, member.address, member.lat, member.lng
  ]);
  
  // 단순 +1이 아니라 실제 개수를 세어서 업데이트 (안전장치)
  if (member.leader_id) {
    recalcLeaderCount(ss, member.leader_id);
  }
  return "OK";
}

function getMembersByLeader(ss, leaderId) {
  const all = getRows("Members");
  return all.filter(m => String(m.leader_id) === String(leaderId));
}

function getAllMembers(ss) {
  return getRows("Members");
}

function removeMember(ss, memberId, leaderId, mode) {
  const sheet = ss.getSheetByName("Members");
  const data = sheet.getDataRange().getValues();
  
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(memberId)) {
      if (mode === 'DELETE') {
        sheet.deleteRow(i + 1);
      } else {
        sheet.getRange(i + 1, 2).setValue(""); // leader_id column is index 2 (1-based)
      }
      break;
    }
  }
  
  // 인원수 재계산
  if (leaderId) {
    recalcLeaderCount(ss, leaderId);
  }
  return "OK";
}

// [핵심] 특정 리더의 실제 순원 수를 세어서 Leaders 시트에 반영하는 함수
function recalcLeaderCount(ss, leaderId) {
  if (!leaderId) return;

  const mSheet = ss.getSheetByName("Members");
  const mData = mSheet.getDataRange().getValues();
  let count = 0;
  // Members: leader_id is index 1
  for (let i = 1; i < mData.length; i++) {
    if (String(mData[i][1]) === String(leaderId)) {
      count++;
    }
  }

  const lSheet = ss.getSheetByName("Leaders");
  const lData = lSheet.getDataRange().getValues();
  // Leaders: id is index 0, current_members is index 10
  for (let i = 1; i < lData.length; i++) {
    if (String(lData[i][0]) === String(leaderId)) {
      lSheet.getRange(i + 1, 11).setValue(count);
      break;
    }
  }
}

// 전체 리더의 인원수 재동기화 (앱 켤 때나 리스트 조회 시 호출)
function refreshAllLeaderCounts(ss) {
  const mSheet = ss.getSheetByName("Members");
  const mData = mSheet.getDataRange().getValues();
  const counts = {};

  // 1. 멤버 전수 조사하여 카운팅
  for (let i = 1; i < mData.length; i++) {
    const lid = mData[i][1];
    if (lid) {
      counts[lid] = (counts[lid] || 0) + 1;
    }
  }

  // 2. 리더 시트에 일괄 반영
  const lSheet = ss.getSheetByName("Leaders");
  const lData = lSheet.getDataRange().getValues();
  
  for (let i = 1; i < lData.length; i++) {
    const lid = lData[i][0];
    const actualCount = counts[lid] || 0;
    // 현재 기록된 값과 다를 경우에만 업데이트 (API 호출 최적화)
    if (lData[i][10] != actualCount) {
      lSheet.getRange(i + 1, 11).setValue(actualCount);
    }
  }
}
`;

const SetupScreen: React.FC<Props> = ({ onComplete }) => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);

  const handleConnect = async () => {
    if (!url.includes('script.google.com')) {
      alert("올바른 Google Apps Script URL이 아닙니다.");
      return;
    }
    
    setLoading(true);
    const success = await checkConnection(url);
    setLoading(false);

    if (success) {
      localStorage.setItem(SHEET_API_URL_KEY, url);
      onComplete();
    } else {
      alert("연결 실패! 스크립트가 올바르게 배포되었는지, 권한이 '모든 사용자(Anyone)'로 설정되었는지 확인해주세요.");
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(GAS_SCRIPT_CODE);
    alert("코드가 클립보드에 복사되었습니다. 구글 앱스 스크립트 에디터에 붙여넣고 저장 후 배포해주세요.");
    setStep(2);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl overflow-hidden">
        <div className="bg-brand-600 p-6 text-white text-center">
          <h1 className="text-2xl font-bold mb-2">개인 데이터베이스 만들기</h1>
          <p className="text-brand-100 text-sm">Google 스프레드시트를 나만의 서버로 사용합니다.</p>
        </div>

        <div className="p-8">
          <div className="space-y-8">
            
            <div className="bg-blue-50 text-blue-800 p-4 rounded-lg text-sm mb-6 border border-blue-100">
               <p className="font-bold mb-1">💡 로컬 앱 실행 안내</p>
               <p>이 파일은 단일 HTML로 동작하며, 연결 정보는 현재 사용 중인 <strong>브라우저에 저장</strong>됩니다. 파일을 다른 컴퓨터로 옮기거나 브라우저 캐시를 지우면 다시 연결해야 합니다.</p>
            </div>

            {/* Step 1 */}
            <div className={`transition-opacity ${step === 1 ? 'opacity-100' : 'opacity-50'}`}>
              <div className="flex items-center gap-3 mb-3">
                <span className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 font-bold flex items-center justify-center border border-slate-200">1</span>
                <h3 className="text-lg font-bold text-slate-800">구글 시트 생성 및 스크립트 복사</h3>
              </div>
              <div className="ml-11 space-y-3 text-sm text-slate-600">
                <p>1. <a href="https://sheets.new" target="_blank" className="text-brand-600 underline font-semibold">새 스프레드시트 만들기</a>를 클릭하여 구글 시트를 생성하세요.</p>
                <p>2. 메뉴에서 <strong>확장 프로그램 &gt; Apps Script</strong>를 클릭하세요.</p>
                <p>3. 아래 코드를 복사하여 에디터에 붙여넣고 저장(Ctrl+S)하세요.</p>
                <div className="relative group">
                  <pre className="bg-slate-900 text-slate-300 p-4 rounded-lg text-xs overflow-x-auto h-32 font-mono">
                    {GAS_SCRIPT_CODE}
                  </pre>
                  <button onClick={copyCode} className="absolute top-2 right-2 bg-white text-slate-900 px-3 py-1 rounded text-xs font-bold hover:bg-slate-200 transition-colors shadow-sm">
                    코드 복사
                  </button>
                </div>
              </div>
            </div>

            {/* Step 2 */}
            <div className={`transition-opacity ${step >= 2 ? 'opacity-100' : 'opacity-40'}`}>
               <div className="flex items-center gap-3 mb-3">
                <span className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 font-bold flex items-center justify-center border border-slate-200">2</span>
                <h3 className="text-lg font-bold text-slate-800">웹 앱으로 배포</h3>
              </div>
              <div className="ml-11 space-y-2 text-sm text-slate-600">
                <p>1. Apps Script 화면 우측 상단 <strong>배포 &gt; 새 배포</strong>를 클릭하세요.</p>
                <p>2. 유형 선택(톱니바퀴)에서 <strong>웹 앱</strong>을 선택하세요.</p>
                <p>3. <strong>액세스 권한이 있는 사용자</strong>를 반드시 <strong>'모든 사용자(Anyone)'</strong>로 설정하고 배포하세요.</p>
                <p className="text-xs text-amber-600 bg-amber-50 p-2 rounded">* '모든 사용자'로 해야 앱에서 데이터를 읽고 쓸 수 있습니다.</p>
              </div>
            </div>

            {/* Step 3 */}
            <div className={`transition-opacity ${step >= 2 ? 'opacity-100' : 'opacity-40'}`}>
               <div className="flex items-center gap-3 mb-3">
                <span className="w-8 h-8 rounded-full bg-brand-100 text-brand-600 font-bold flex items-center justify-center border border-brand-200">3</span>
                <h3 className="text-lg font-bold text-slate-800">연결하기</h3>
              </div>
              <div className="ml-11">
                <label className="block text-sm font-bold text-slate-700 mb-2">웹 앱 URL 붙여넣기</label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={url} 
                    onChange={e => setUrl(e.target.value)} 
                    placeholder="https://script.google.com/macros/s/..." 
                    className="flex-1 rounded-lg border-slate-300 shadow-sm focus:border-brand-500 focus:ring-brand-500 px-3 py-2 border"
                  />
                  <button 
                    onClick={handleConnect}
                    disabled={loading || !url}
                    className="bg-brand-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-brand-700 disabled:opacity-50 transition-colors whitespace-nowrap"
                  >
                    {loading ? '확인 중...' : '연동 시작'}
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default SetupScreen;