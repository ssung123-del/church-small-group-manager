import React, { useEffect, useRef } from 'react';
import { Leader, ScoredLeader } from '../types';

interface Props {
  leaders: ScoredLeader[] | Leader[];
  targetLocation?: { lat: number; lng: number } | null;
}

// Custom Map Style to make it look cleaner (hide business POIs, soften colors)
const MAP_STYLES = [
  {
    "featureType": "poi.business",
    "stylers": [{ "visibility": "off" }]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [{ "color": "#e5e5e5" }]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [{ "color": "#c9c9c9" }]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [{ "color": "#ffffff" }]
  },
  {
    "featureType": "landscape",
    "elementType": "geometry",
    "stylers": [{ "color": "#f5f5f5" }]
  }
];

const MapVisualizer: React.FC<Props> = ({ leaders, targetLocation }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);

  useEffect(() => {
    if (!mapRef.current || !window.google) return;

    if (!mapInstanceRef.current) {
      const defaultCenter = { lat: 37.5665, lng: 126.9780 }; // Seoul default
      mapInstanceRef.current = new window.google.maps.Map(mapRef.current, {
        center: defaultCenter,
        zoom: 12,
        disableDefaultUI: false,
        styles: MAP_STYLES, // Apply custom styles
        zoomControl: true,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: true,
      });
    }

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    const bounds = new window.google.maps.LatLngBounds();
    let hasPoints = false;

    // 1. Add Target Member Marker (Red with animation)
    if (targetLocation) {
      const marker = new window.google.maps.Marker({
        position: targetLocation,
        map: mapInstanceRef.current,
        title: "신규 순원 위치",
        animation: window.google.maps.Animation.BOUNCE, // Bounce animation for emphasis
        icon: {
          url: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png',
          scaledSize: new window.google.maps.Size(40, 40) // Slightly larger
        }
      });
      markersRef.current.push(marker);
      bounds.extend(targetLocation);
      hasPoints = true;
    }

    // 2. Add Leader Markers (Blue)
    leaders.forEach((leader) => {
      const isScored = 'distance' in leader;
      
      const marker = new window.google.maps.Marker({
        position: { lat: leader.lat, lng: leader.lng },
        map: mapInstanceRef.current,
        title: `${leader.name} ${leader.role}`,
        icon: {
          url: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
          scaledSize: new window.google.maps.Size(32, 32)
        },
        label: isScored ? { 
          text: (leaders.indexOf(leader) + 1).toString(), 
          color: "white",
          fontSize: "14px",
          fontWeight: "bold"
        } : null
      });

      // Custom styled InfoWindow content
      const contentString = `
        <div style="padding: 8px; font-family: sans-serif;">
          <h3 style="margin:0 0 4px 0; font-size:16px; font-weight:bold; color:#1e40af;">${leader.name} ${leader.role}</h3>
          <p style="margin:0; font-size:13px; color:#4b5563;">${leader.age}세 · ${leader.gender === 'Male' ? '남성' : '여성'}</p>
          <p style="margin:4px 0; font-size:12px; color:#6b7280; border-bottom:1px solid #e5e7eb; padding-bottom:4px;">${leader.address}</p>
          <div style="margin-top:4px; font-size:13px;">
            <span style="font-weight:600; color:#059669;">현재원: ${leader.current_members}명</span> 
            <span style="color:#9ca3af;">(최대 ${leader.max_capacity}명)</span>
          </div>
          ${isScored ? `
            <div style="margin-top:6px; background-color:#eff6ff; padding:4px; border-radius:4px; font-size:12px;">
              <p style="margin:0; color:#2563eb; font-weight:bold;">거리: ${(leader as ScoredLeader).distance?.toFixed(2)} km</p>
            </div>` : ''}
        </div>
      `;

      const infoWindow = new window.google.maps.InfoWindow({
        content: contentString,
        minWidth: 200,
      });

      marker.addListener('click', () => {
        // Close other open info windows (optional, but good UX)
        // In a real app, you might track the currently open infoWindow ref
        infoWindow.open(mapInstanceRef.current, marker);
      });

      markersRef.current.push(marker);
      bounds.extend({ lat: leader.lat, lng: leader.lng });
      hasPoints = true;
    });

    if (hasPoints) {
      mapInstanceRef.current.fitBounds(bounds);
      // Avoid zooming in too far if only one point
      const listener = window.google.maps.event.addListenerOnce(mapInstanceRef.current, "idle", () => { 
        if (mapInstanceRef.current.getZoom() > 16) mapInstanceRef.current.setZoom(16); 
      });
    }

  }, [leaders, targetLocation]);

  return (
    <div className="relative w-full h-full min-h-[400px] rounded-xl overflow-hidden shadow-lg border border-gray-200">
      <div ref={mapRef} className="w-full h-full bg-gray-100" />
      {/* Map Overlay Badge (Optional) */}
      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full shadow-md text-xs font-semibold text-gray-600 z-10 border border-gray-200">
        Google Maps
      </div>
    </div>
  );
};

export default MapVisualizer;