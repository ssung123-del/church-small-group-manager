import React, { useEffect, useRef, useState } from 'react';
import { fetchFullData } from '../services/googleSheetService';
import { Leader, Member } from '../types';

interface DashboardStats {
  leaderCount: number;
  memberCount: number;
  unassignedCount: number;
  occupancyRate: number;
  genderRatio: { male: number; female: number };
  ageGroups: { [key: string]: number };
}

const Dashboard: React.FC = () => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]); // Track markers to clear them properly

  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStats>({
    leaderCount: 0,
    memberCount: 0,
    unassignedCount: 0,
    occupancyRate: 0,
    genderRatio: { male: 0, female: 0 },
    ageGroups: {}
  });

  useEffect(() => {
    loadDataAndDrawMap();
  }, []);

  const loadDataAndDrawMap = async () => {
    setLoading(true);
    try {
      const { leaders, members } = await fetchFullData();
      
      // --- 1. 통계 계산 ---
      const unassigned = members.filter(m => !m.leader_id).length;
      const totalCapacity = leaders.reduce((sum, l) => sum + (l.max_capacity || 0), 0);
      const currentAssigned = members.length - unassigned;
      const occupancy = totalCapacity > 0 ? Math.round((currentAssigned / totalCapacity) * 100) : 0;

      const male = members.filter(m => m.gender === 'Male' || !m.gender).length;
      const female = members.length - male;

      const ageGroups: { [key: string]: number } = { '20대': 0, '30대': 0, '40대': 0, '50대': 0, '60대+': 0 };
      members.forEach(m => {
        const age = m.age || 0;
        if (age < 30) ageGroups['20대']++;
        else if (age < 40) ageGroups['30대']++;
        else if (age < 50) ageGroups['40대']++;
        else if (age < 60) ageGroups['50대']++;
        else ageGroups['60대+']++;
      });

      setStats({
        leaderCount: leaders.length,
        memberCount: members.length,
        unassignedCount: unassigned,
        occupancyRate: occupancy,
        genderRatio: { male, female },
        ageGroups
      });
      
      // --- 2. 지도 그리기 ---
      initMap(leaders, members);

    } catch (err) {
      console.error(err);
      alert("데이터를 불러오는 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  };

  const initMap = (leaders: Leader[], members: Member[]) => {
    if (!mapRef.current || !window.google) return;

    // 지도 인스턴스가 없으면 생성
    if (!mapInstanceRef.current) {
      mapInstanceRef.current = new window.google.maps.Map(mapRef.current, {
        center: { lat: 36.5, lng: 127.8 }, // 대한민국 중심
        zoom: 7,
        disableDefaultUI: true,
        zoomControl: true,
        styles: [
            { "featureType": "poi", "stylers": [{ "visibility": "off" }] },
            { "featureType": "transit", "stylers": [{ "visibility": "off" }] }
        ]
      });
    }

    // 기존 마커 제거 (중복 방지)
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    const map = mapInstanceRef.current;
    const bounds = new window.google.maps.LatLngBounds();
    let hasPoints = false;

    // 1. 소그룹원 그리기 (작은 점)
    members.forEach((m: Member) => {
      // 위도/경도가 유효한 경우만
      if (m.lat && m.lng) {
        const isUnassigned = !m.leader_id;
        const marker = new window.google.maps.Marker({
          position: { lat: m.lat, lng: m.lng },
          map: map,
          icon: {
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: isUnassigned ? 4 : 3,
            fillColor: isUnassigned ? "#ef4444" : "#94a3b8", // 미배정: 빨강, 배정됨: 회색
            fillOpacity: 0.8,
            strokeWeight: isUnassigned ? 1 : 0,
            strokeColor: "#ffffff"
          },
          title: `[소그룹원] ${m.name}`
        });
        markersRef.current.push(marker);
        bounds.extend({ lat: m.lat, lng: m.lng });
        hasPoints = true;
      }
    });

    // 2. 리더 그리기 (큰 핀)
    leaders.forEach((l: Leader) => {
      if (l.lat && l.lng) {
        const isFull = l.current_members >= l.max_capacity;
        
        const marker = new window.google.maps.Marker({
          position: { lat: l.lat, lng: l.lng },
          map: map,
          title: `[리더] ${l.name}`,
          label: {
              text: `${l.current_members}`,
              color: "white",
              fontSize: "10px",
              fontWeight: "bold"
          },
          zIndex: 100, // 멤버보다 위에 표시
          icon: {
             url: isFull 
                ? 'http://maps.google.com/mapfiles/ms/icons/red-dot.png' // 만원이면 빨간핀
                : 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png' // 여유있으면 파란핀
          }
        });
        
        // 정보창 (클릭 시 표시)
        const infoWindow = new window.google.maps.InfoWindow({
            content: `
                <div style="padding:4px; min-width:120px;">
                    <strong style="font-size:14px; color:#1e40af;">${l.name} ${l.role}</strong>
                    <div style="font-size:12px; color:#4b5563; margin-top:2px;">
                       ${l.age}세 · ${l.gender === 'Male' ? '남성' : '여성'}
                    </div>
                    <div style="margin:4px 0; border-top:1px solid #eee; padding-top:4px;">
                      <span style="font-weight:bold; color:${isFull ? '#dc2626' : '#059669'};">
                        현원: ${l.current_members} / ${l.max_capacity}명
                      </span>
                    </div>
                    <div style="font-size:11px; color:#9ca3af;">${l.address}</div>
                </div>
            `
        });
        
        marker.addListener('click', () => {
            infoWindow.open(map, marker);
        });

        markersRef.current.push(marker);
        bounds.extend({ lat: l.lat, lng: l.lng });
        hasPoints = true;
      }
    });

    // 데이터가 하나라도 있으면 지도 범위를 데이터에 맞춤
    if (hasPoints) {
      map.fitBounds(bounds);
      
      // 데이터가 너무 적어서 줌이 너무 땡겨지는 것 방지
      const listener = window.google.maps.event.addListenerOnce(map, "idle", () => { 
        if (map.getZoom() > 15) map.setZoom(15); 
      });
    }
  };

  const maxAgeCount = Math.max(...Object.values(stats.ageGroups), 1);

  return (
    <div className="h-full flex flex-col space-y-6 pb-8">
      
      {/* 1. 상단 핵심 지표 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* 총원 */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
           <div className="flex justify-between items-start mb-2">
             <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">총 소그룹원</p>
             <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
             </div>
           </div>
           <p className="text-3xl font-black text-slate-800">{stats.memberCount}<span className="text-sm font-medium text-slate-400 ml-1">명</span></p>
        </div>

        {/* 미배정 (중요) */}
        <div className={`p-5 rounded-2xl shadow-sm border ${stats.unassignedCount > 0 ? 'bg-red-50 border-red-200' : 'bg-white border-slate-200'}`}>
           <div className="flex justify-between items-start mb-2">
             <p className={`text-xs font-bold uppercase tracking-wider ${stats.unassignedCount > 0 ? 'text-red-600' : 'text-slate-500'}`}>미배정 인원</p>
             <div className={`p-2 rounded-lg ${stats.unassignedCount > 0 ? 'bg-white text-red-500' : 'bg-slate-100 text-slate-500'}`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
             </div>
           </div>
           <p className={`text-3xl font-black ${stats.unassignedCount > 0 ? 'text-red-600' : 'text-slate-800'}`}>{stats.unassignedCount}<span className="text-sm font-medium opacity-60 ml-1">명</span></p>
        </div>

        {/* 수용률 */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
           <div className="flex justify-between items-start mb-2">
             <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">전체 수용률</p>
             <div className="p-2 bg-green-50 text-green-600 rounded-lg">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
             </div>
           </div>
           <div className="flex items-baseline gap-2">
               <p className="text-3xl font-black text-slate-800">{stats.occupancyRate}%</p>
               <span className="text-xs text-slate-400 font-medium">정원 대비</span>
           </div>
           <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
               <div className="h-full bg-green-500 rounded-full" style={{ width: `${Math.min(stats.occupancyRate, 100)}%` }}></div>
           </div>
        </div>

        {/* 리더 수 */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
           <div className="flex justify-between items-start mb-2">
             <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">활성 리더</p>
             <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
             </div>
           </div>
           <p className="text-3xl font-black text-slate-800">{stats.leaderCount}<span className="text-sm font-medium text-slate-400 ml-1">명</span></p>
        </div>
      </div>

      {/* 2. 지도 및 상세 통계 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-[500px]">
        
        {/* 지도 영역 (2/3 차지) */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden relative flex flex-col h-[500px] lg:h-auto">
            <div className="px-5 py-3 border-b border-slate-100 bg-slate-50 flex justify-between items-center z-10">
                <h3 className="font-bold text-slate-700">지역별 분포 현황</h3>
                <div className="flex items-center gap-3">
                    <button 
                        onClick={loadDataAndDrawMap} 
                        className="text-xs bg-white border border-slate-300 px-2 py-1 rounded hover:bg-slate-50 transition-colors"
                    >
                        새로고침
                    </button>
                    <div className="flex gap-3 text-xs font-medium">
                        <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-600"></span> 리더</div>
                        <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-400"></span> 순원</div>
                        <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500"></span> 미배정</div>
                    </div>
                </div>
            </div>
            
            <div className="flex-1 relative w-full h-full">
                {loading && (
                    <div className="absolute inset-0 z-20 bg-white/80 backdrop-blur-sm flex items-center justify-center">
                        <div className="flex flex-col items-center gap-2">
                            <div className="w-8 h-8 border-4 border-brand-200 border-t-brand-600 rounded-full animate-spin"></div>
                            <span className="text-sm font-medium text-slate-500">지도 데이터 분석 중...</span>
                        </div>
                    </div>
                )}
                <div ref={mapRef} className="w-full h-full bg-slate-100 min-h-[400px]"></div>
            </div>
        </div>

        {/* 통계 컬럼 (1/3 차지) */}
        <div className="space-y-6 flex flex-col">
            
            {/* 연령별 분포 */}
            <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 flex-1">
                <h3 className="font-bold text-slate-800 mb-6">연령별 분포</h3>
                <div className="space-y-5">
                    {Object.entries(stats.ageGroups).map(([age, count]) => (
                        <div key={age}>
                            <div className="flex justify-between text-sm mb-1">
                                <span className="font-medium text-slate-600">{age}</span>
                                <span className="font-bold text-slate-800">{count}명</span>
                            </div>
                            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                                <div 
                                    className="h-full bg-brand-500 rounded-full transition-all duration-1000" 
                                    style={{ width: `${(count / maxAgeCount) * 100}%` }}
                                ></div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* 성별 비율 */}
            <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-800 mb-4">성별 비율</h3>
                <div className="flex items-center gap-4">
                    <div className="flex-1 flex flex-col items-center p-3 bg-blue-50 rounded-xl border border-blue-100">
                        <span className="text-2xl mb-1">👨</span>
                        <span className="text-xs font-bold text-blue-700 uppercase">남성</span>
                        <span className="text-lg font-black text-slate-800">{stats.genderRatio.male}</span>
                    </div>
                    <div className="flex-1 flex flex-col items-center p-3 bg-pink-50 rounded-xl border border-pink-100">
                        <span className="text-2xl mb-1">👩</span>
                        <span className="text-xs font-bold text-pink-700 uppercase">여성</span>
                        <span className="text-lg font-black text-slate-800">{stats.genderRatio.female}</span>
                    </div>
                </div>
            </div>

        </div>
      </div>
    </div>
  );
};

export default Dashboard;