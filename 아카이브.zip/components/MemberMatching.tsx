import React, { useState, useEffect } from 'react';
import { geocodeAddress, findClosestLeaders } from '../services/geoService';
import { fetchLeaders, insertMember } from '../services/googleSheetService';
import { Leader, ScoredLeader } from '../types';
import MapVisualizer from './MapVisualizer';
import AddressAutocomplete from './AddressAutocomplete';

const MemberMatching: React.FC = () => {
  // Form State
  const [formData, setFormData] = useState({
    name: '',
    role: '성도',
    age: '',
    gender: 'Male',
    contact: '',
    address: ''
  });
  
  const [loading, setLoading] = useState(false);
  const [candidates, setCandidates] = useState<ScoredLeader[]>([]);
  const [targetLocation, setTargetLocation] = useState<{lat: number, lng: number} | null>(null);
  const [selectedLeaderId, setSelectedLeaderId] = useState<number | null>(null);
  const [, setAllLeaders] = useState<Leader[]>([]); // Cache for logic

  useEffect(() => {
    // Silent pre-fetch
    fetchLeaders().then(setAllLeaders).catch(console.error);
  }, []);

  const handleSearch = async (e?: React.FormEvent) => {
    if(e) e.preventDefault();
    
    if (!formData.address || !formData.age) {
        alert("정확한 매칭을 위해 주소와 나이를 입력해주세요.");
        return;
    }

    setLoading(true);
    setCandidates([]);
    setSelectedLeaderId(null);

    try {
      const leadersData = await fetchLeaders(); // Get fresh data
      setAllLeaders(leadersData);

      // Note: If using autocomplete, the address is likely already formatted, 
      // but geocoding ensures we get the lat/lng.
      const geo = await geocodeAddress(formData.address);
      setTargetLocation({ lat: geo.lat, lng: geo.lng });
      // Update form with the official formatted address
      setFormData(prev => ({...prev, address: geo.formattedAddress})); 

      const targetAge = parseInt(formData.age);
      const results = findClosestLeaders(geo.lat, geo.lng, targetAge, leadersData, 3);
      setCandidates(results);
      
      if (results.length === 0) {
        alert("조건에 맞는 리더를 찾을 수 없습니다.");
      }

    } catch (err: any) {
      alert(`검색 중 오류가 발생했습니다: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleAssign = async () => {
    if (!selectedLeaderId || !targetLocation || !formData.name) return;

    const leaderName = candidates.find(c => c.id === selectedLeaderId)?.name;
    if (!confirm(`${formData.name} 님을 '${leaderName}' 리더에게 배정하시겠습니까?`)) return;

    setLoading(true);
    try {
      await insertMember({
        name: formData.name,
        role: formData.role,
        age: parseInt(formData.age),
        contact: formData.contact,
        address: formData.address,
        lat: targetLocation.lat,
        lng: targetLocation.lng,
        leader_id: selectedLeaderId
      });
      
      alert("배정이 완료되었습니다.");
      
      // Reset critical fields
      setFormData({ ...formData, name: '', contact: '', address: '' });
      setCandidates([]);
      setTargetLocation(null);
      setSelectedLeaderId(null);
    } catch (err: any) {
      alert("배정 실패: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const inputBaseClass = "block w-full rounded-lg border-slate-200 bg-slate-50 text-slate-900 focus:border-brand-500 focus:ring-brand-500 sm:text-sm py-2.5 transition-shadow shadow-sm placeholder:text-slate-400 border px-3";
  const labelClass = "block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wide";

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 h-full min-h-[calc(100vh-140px)]">
      
      {/* LEFT: Input & Results Panel */}
      <div className="xl:col-span-5 flex flex-col space-y-6">
        
        {/* 1. Input Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
            <h2 className="font-bold text-slate-800 flex items-center gap-2">
              <span className="flex items-center justify-center w-6 h-6 rounded-full bg-brand-100 text-brand-600 text-xs">1</span>
              새 소그룹원 정보 입력
            </h2>
            <button 
                type="button" 
                onClick={() => setFormData({name: '', role: '성도', age: '', gender: 'Male', contact: '', address: ''})}
                className="text-xs text-slate-400 hover:text-brand-600 font-medium"
            >
                초기화
            </button>
          </div>
          
          <form onSubmit={handleSearch} className="p-6 space-y-5">
            <div className="grid grid-cols-2 gap-5">
              <div>
                <label className={labelClass}>이름</label>
                <input type="text" required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className={inputBaseClass} placeholder="홍길동" />
              </div>
              <div>
                <label className={labelClass}>직분</label>
                <input type="text" value={formData.role} onChange={e => setFormData({...formData, role: e.target.value})} className={inputBaseClass} placeholder="성도" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-5">
              <div>
                <label className={labelClass}>나이</label>
                <input type="number" required value={formData.age} onChange={e => setFormData({...formData, age: e.target.value})} className={inputBaseClass} placeholder="40" />
              </div>
              <div>
                <label className={labelClass}>성별</label>
                <select value={formData.gender} onChange={e => setFormData({...formData, gender: e.target.value})} className={inputBaseClass}>
                  <option value="Male">남성</option>
                  <option value="Female">여성</option>
                </select>
              </div>
            </div>

            <div>
              <label className={labelClass}>주소 (자동완성)</label>
              <div className="flex gap-2 relative">
                <AddressAutocomplete 
                    value={formData.address}
                    onChange={(val) => setFormData({...formData, address: val})}
                    onPlaceSelected={(addr) => {
                        setFormData(prev => ({...prev, address: addr}));
                        // Optional: Auto-trigger search? No, user might want to change age first.
                    }}
                    placeholder="도로명 주소 입력 (선택)"
                    className={inputBaseClass}
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 px-4 rounded-xl shadow-md shadow-brand-500/20 active:scale-[0.98] transition-all disabled:opacity-50 disabled:shadow-none flex justify-center items-center gap-2"
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                  <span>분석 중...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                  <span>소그룹 리더 찾기</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* 2. Results List */}
        {candidates.length > 0 && (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex-1 flex flex-col animate-fade-in-up">
            <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
              <h2 className="font-bold text-slate-800 flex items-center gap-2">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-100 text-green-600 text-xs">2</span>
                추천 결과
                <span className="text-xs font-normal text-slate-500 ml-auto bg-white border px-2 py-0.5 rounded-full">가까운 순</span>
              </h2>
            </div>
            
            <div className="p-4 space-y-3 overflow-y-auto max-h-[400px]">
              {candidates.map((leader, idx) => {
                const isSelected = selectedLeaderId === leader.id;
                const isBest = idx === 0;
                
                return (
                  <div 
                    key={leader.id}
                    onClick={() => setSelectedLeaderId(leader.id!)}
                    className={`group relative p-4 rounded-xl border transition-all cursor-pointer ${
                      isSelected 
                        ? 'border-brand-500 bg-brand-50 shadow-md ring-1 ring-brand-500' 
                        : 'border-slate-200 bg-white hover:border-brand-300 hover:shadow-sm'
                    }`}
                  >
                    {isBest && !isSelected && (
                      <div className="absolute -top-2 -right-2 bg-yellow-400 text-yellow-900 text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm z-10">
                        BEST
                      </div>
                    )}
                    
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2 mb-1">
                          <h3 className={`text-base font-bold truncate ${isSelected ? 'text-brand-900' : 'text-slate-800'}`}>
                            {leader.name}
                          </h3>
                          <span className="text-xs text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">{leader.role}</span>
                          <span className="text-xs text-slate-400">{leader.age}세</span>
                        </div>
                        <p className="text-xs text-slate-500 truncate mb-3">{leader.address}</p>
                        
                        <div className="flex gap-2 text-xs">
                          <div className={`px-2 py-1 rounded font-medium flex items-center gap-1 ${leader.current_members >= leader.max_capacity ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-600'}`}>
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                            {leader.current_members} / {leader.max_capacity}명
                          </div>
                          <div className="px-2 py-1 rounded bg-slate-100 text-slate-600 font-medium">
                            나이차 {leader.ageDiff}살
                          </div>
                        </div>
                      </div>

                      <div className="text-right pl-3 flex flex-col items-end">
                        <div className="text-xl font-black text-brand-600 leading-none">
                          {leader.distance.toFixed(1)}
                          <span className="text-xs font-medium text-slate-400 ml-0.5">km</span>
                        </div>
                        {isSelected && (
                          <div className="mt-3 text-brand-600 animate-bounce">
                            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50 mt-auto">
              <button
                onClick={handleAssign}
                disabled={!selectedLeaderId || loading}
                className="w-full bg-green-600 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-green-600/20 hover:bg-green-700 disabled:bg-slate-300 disabled:shadow-none disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
              >
                <span>배정 확정하기</span>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" /></svg>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* RIGHT: Map Panel */}
      <div className="xl:col-span-7 h-[400px] xl:h-auto rounded-2xl overflow-hidden shadow-sm border border-slate-200 sticky top-24 xl:min-h-[600px]">
        <MapVisualizer leaders={candidates} targetLocation={targetLocation} />
      </div>

    </div>
  );
};

export default MemberMatching;