import React, { useEffect, useState } from 'react';
import { Leader, Member } from '../types';
import { fetchMembersByLeader, removeMember } from '../services/googleSheetService';

interface Props {
  leader: Leader;
  onClose: () => void;
  onUpdate: () => void; // Trigger refresh in parent
}

const MemberManagementModal: React.FC<Props> = ({ leader, onClose, onUpdate }) => {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMembers();
  }, [leader]);

  const loadMembers = async () => {
    if (!leader.id) return;
    setLoading(true);
    try {
      const data = await fetchMembersByLeader(leader.id);
      setMembers(data);
    } catch (err) {
      console.error(err);
      alert("데이터 로드 실패");
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (memberId: number, type: 'DELETE' | 'UNASSIGN') => {
    if (!leader.id) return;
    const msg = type === 'DELETE' 
      ? "정말 삭제하시겠습니까? 데이터가 영구히 사라집니다." 
      : "이 소그룹에서 제외하시겠습니까? (미배정 상태가 됩니다)";
      
    if (!confirm(msg)) return;

    try {
      await removeMember(memberId, leader.id, type);
      await loadMembers(); // Reload list
      onUpdate(); // Update parent counters
    } catch (err: any) {
      alert("처리 실패: " + err.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[80vh]">
        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <div>
            <h3 className="text-lg font-bold text-slate-800">{leader.name} 리더의 소그룹원</h3>
            <p className="text-xs text-slate-500">총 {members.length}명 / 정원 {leader.max_capacity}명</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-2 rounded-full hover:bg-slate-200 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-0">
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <div className="w-8 h-8 border-4 border-brand-200 border-t-brand-600 rounded-full animate-spin"></div>
            </div>
          ) : members.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-slate-400 space-y-2">
              <svg className="w-10 h-10 opacity-20" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" /></svg>
              <p>배정된 소그룹원이 없습니다.</p>
            </div>
          ) : (
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 uppercase font-semibold">
                <tr>
                  <th className="px-6 py-3">이름/직분</th>
                  <th className="px-6 py-3">연락처/주소</th>
                  <th className="px-6 py-3 text-right">관리</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {members.map(m => (
                  <tr key={m.id} className="hover:bg-slate-50/50">
                    <td className="px-6 py-3">
                      <div className="font-bold text-slate-900">{m.name}</div>
                      <div className="text-xs text-slate-500">{m.role} · {m.age}세</div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="text-xs text-slate-500 mb-0.5">{m.contact || '-'}</div>
                      <div className="text-slate-700 truncate max-w-[200px]" title={m.address}>{m.address}</div>
                    </td>
                    <td className="px-6 py-3 text-right space-x-2">
                      <button 
                        onClick={() => m.id && handleRemove(m.id, 'UNASSIGN')}
                        className="text-xs text-amber-600 hover:text-amber-800 font-medium hover:underline"
                      >
                        제외
                      </button>
                      <span className="text-slate-300">|</span>
                      <button 
                        onClick={() => m.id && handleRemove(m.id, 'DELETE')}
                        className="text-xs text-red-600 hover:text-red-800 font-medium hover:underline"
                      >
                        삭제
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 text-right">
           <button onClick={onClose} className="px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-semibold text-slate-700 hover:bg-slate-50 shadow-sm">
             닫기
           </button>
        </div>
      </div>
    </div>
  );
};

export default MemberManagementModal;