import { Leader, Member } from '../types';
import { SHEET_API_URL_KEY } from '../constants';

const getApiUrl = () => localStorage.getItem(SHEET_API_URL_KEY);

const request = async (action: string, payload: any = {}) => {
  const url = getApiUrl();
  if (!url) throw new Error("데이터베이스가 연결되지 않았습니다.");

  // Google Apps Script requires POST for payloads, and text/plain to avoid CORS preflight issues locally
  const response = await fetch(url, {
    method: 'POST',
    body: JSON.stringify({ action, ...payload }),
  });

  const result = await response.json();
  if (result.status === 'error') {
    throw new Error(result.message);
  }
  return result.data;
};

export const fetchLeaders = async (): Promise<Leader[]> => {
  return await request('GET_LEADERS');
};

export const insertLeader = async (leader: Leader) => {
  return await request('ADD_LEADER', { leader });
};

export const deleteLeader = async (id: number) => {
  return await request('DELETE_LEADER', { id });
};

export const insertMember = async (member: Member) => {
  return await request('ADD_MEMBER', { member });
};

export const fetchMembersByLeader = async (leaderId: number): Promise<Member[]> => {
  return await request('GET_MEMBERS_BY_LEADER', { leaderId });
};

export const fetchFullData = async () => {
  const [leaders, members] = await Promise.all([
    request('GET_LEADERS'),
    request('GET_ALL_MEMBERS')
  ]);
  return { leaders, members };
};

export const removeMember = async (memberId: number, leaderId: number, mode: 'DELETE' | 'UNASSIGN') => {
  return await request('REMOVE_MEMBER', { memberId, leaderId, mode });
};

// Helper to check connection
export const checkConnection = async (url: string): Promise<boolean> => {
  try {
    const response = await fetch(url, {
        method: 'POST',
        body: JSON.stringify({ action: 'PING' })
    });
    const result = await response.json();
    return result.status === 'success';
  } catch (e) {
    return false;
  }
};