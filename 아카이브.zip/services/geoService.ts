import { GeocodeResult, Leader, ScoredLeader } from '../types';
import { GEOCODE_DELAY_MS } from '../constants';

// Helper for delay
export const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Geocode address using Google Maps Geocoder
export const geocodeAddress = async (address: string): Promise<GeocodeResult> => {
  if (!window.google || !window.google.maps) {
    throw new Error("Google Maps API not loaded");
  }

  const geocoder = new window.google.maps.Geocoder();
  
  return new Promise((resolve, reject) => {
    geocoder.geocode({ address: address }, (results: any[], status: string) => {
      if (status === 'OK' && results[0]) {
        resolve({
          lat: results[0].geometry.location.lat(),
          lng: results[0].geometry.location.lng(),
          formattedAddress: results[0].formatted_address
        });
      } else {
        reject(new Error(`Geocode failed: ${status}`));
      }
    });
  });
};

// Haversine formula to calculate distance in km
export const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLng = deg2rad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // Distance in km
  return d;
};

const deg2rad = (deg: number): number => {
  return deg * (Math.PI / 180);
};

// Modified to consider Target Age
export const findClosestLeaders = (
  targetLat: number, 
  targetLng: number, 
  targetAge: number, // Added target age
  leaders: Leader[], 
  topN: number = 3
): ScoredLeader[] => {
  
  const scored = leaders.map(leader => {
    const distance = calculateDistance(targetLat, targetLng, leader.lat, leader.lng);
    const ageDiff = Math.abs(leader.age - targetAge);
    
    // Scoring Formula:
    // Distance has base weight.
    // Age difference penalty: 5 years difference is roughly treated as 1km penalty.
    // Score = Distance(km) + (AgeDiff * 0.2)
    // Lower score is better.
    const score = distance + (ageDiff * 0.2);

    return {
      ...leader,
      distance,
      ageDiff,
      score
    };
  });

  // Sort by Score (asc)
  scored.sort((a, b) => a.score - b.score);

  return scored.slice(0, topN);
};