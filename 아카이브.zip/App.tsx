import React, { useState, useEffect } from 'react';
import LeaderUpload from './components/LeaderUpload';
import MemberMatching from './components/MemberMatching';
import Dashboard from './components/Dashboard';
import GoogleMapLoader from './components/GoogleMapLoader';
import SetupScreen from './components/SheetSetup';
import { SHEET_API_URL_KEY } from './constants';

enum Tab {
  MATCH = 'MATCH',
  UPLOAD = 'UPLOAD',
  DASHBOARD = 'DASHBOARD'
}

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.MATCH);
  const [mapsLoaded, setMapsLoaded] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [checking, setChecking] = useState(true);
  const [showGuide, setShowGuide] = useState(false);

  useEffect(() => {
    // Check if we have a connected sheet
    const url = localStorage.getItem(SHEET_API_URL_KEY);
    if (url) {
      setIsConnected(true);
    }
    setChecking(false);
  }, []);

  const handleSetupComplete = () => {
    setIsConnected(true);
  };

  const handleDisconnect = () => {
    if(confirm("데이터베이스 연결을 끊으시겠습니까? 다시 연결해야 합니다.")) {
        localStorage.removeItem(SHEET_API_URL_KEY);
        setIsConnected(false);
    }
  };

  if (checking) return null;

  if (!isConnected) {
    return <SetupScreen onComplete={handleSetupComplete} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Modern Header */}
      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-auto sm:h-16 py-3 sm:py-0 flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-0">
          
          {/* Logo Section */}
          <div className="flex items-center gap-2.5 self-start sm:self-auto group cursor-pointer" onClick={handleDisconnect} title="연결 해제하려면 클릭하세요">
            <div className="bg-green-600 p-1.5 rounded-lg text-white shadow-green-500/30 shadow-lg group-hover:bg-red-500 transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 tracking-tight leading-none">소그룹 편성 매니저</h1>
              <p className="text-[10px] text-green-600 font-medium tracking-wide uppercase mt-0.5 flex items-center gap-1">
                 <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                 Google Sheets DB
              </p>
            </div>
          </div>

          {/* Navigation & Help */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
             <nav className="flex bg-slate-100/80 p-1 rounded-xl flex-1 sm:flex-none">
                <button
                onClick={() => setActiveTab(Tab.MATCH)}
                className={`flex-1 sm:flex-none px-4 py-2 sm:py-1.5 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center justify-center text-center ${
                    activeTab === Tab.MATCH
                    ? 'bg-white text-brand-600 shadow-sm ring-1 ring-black/5'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
                >
                소그룹 배정
                </button>
                <button
                onClick={() => setActiveTab(Tab.UPLOAD)}
                className={`flex-1 sm:flex-none px-4 py-2 sm:py-1.5 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center justify-center text-center ${
                    activeTab === Tab.UPLOAD
                    ? 'bg-white text-brand-600 shadow-sm ring-1 ring-black/5'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
                >
                데이터 관리
                </button>
                <button
                onClick={() => setActiveTab(Tab.DASHBOARD)}
                className={`flex-1 sm:flex-none px-4 py-2 sm:py-1.5 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center justify-center text-center ${
                    activeTab === Tab.DASHBOARD
                    ? 'bg-white text-brand-600 shadow-sm ring-1 ring-black/5'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
                >
                전체 현황
                </button>
            </nav>
            
            {/* Download Guide Button */}
            <button 
              onClick={() => setShowGuide(true)}
              className="p-2 text-slate-400 hover:text-brand-600 hover:bg-slate-100 rounded-full transition-colors hidden sm:block"
              title="앱 다운로드 가이드"
            >
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
            </button>
          </div>
        </div>
      </header>

      {/* Download Guide Modal */}
      {showGuide && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in" onClick={() => setShowGuide(false)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 space-y-4" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-start">
                <h3 className="text-xl font-bold text-slate-900">내 컴퓨터에 앱 저장하기</h3>
                <button onClick={() => setShowGuide(false)} className="text-slate-400 hover:text-slate-600"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
            </div>
            
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-sm space-y-4">
                <div className="bg-amber-50 text-amber-900 p-3 rounded-lg text-xs font-bold flex gap-3 items-start border border-amber-100">
                   <span className="text-xl">🤔</span>
                   <div>
                       <p className="mb-1 text-sm">혹시 터미널이 안 보이시나요?</p>
                       <p className="font-normal text-amber-800 leading-relaxed">
                         터미널은 <strong>이 앱 화면(Preview) 안</strong>에 있는 버튼이 아닙니다!<br/>
                         지금 코드가 보이는 <strong>'웹 에디터 전체 화면'</strong>의 맨 아래쪽을 확인해주세요.<br/>
                         (보통 <code className="bg-amber-100 px-1 rounded">Terminal</code> 이나 <code className="bg-amber-100 px-1 rounded">&gt;_</code> 아이콘으로 표시됩니다)
                       </p>
                   </div>
                </div>

                <div className="space-y-3">
                    <p className="font-bold text-slate-800">🚀 따라해 보세요:</p>
                    <ol className="list-decimal list-inside space-y-2 text-slate-700 font-medium text-sm ml-1">
                        <li>
                          키보드 단축키 <code className="bg-slate-200 px-1.5 py-0.5 rounded text-xs border border-slate-300">Ctrl</code> + <code className="bg-slate-200 px-1.5 py-0.5 rounded text-xs border border-slate-300">`</code> (숫자 1 왼쪽 키) 누르기
                        </li>
                        <li>
                          나타난 검은색 창(터미널)에 아래 명령어 입력 후 엔터:
                          <div className="mt-1.5 bg-slate-800 text-green-400 p-2 rounded-lg font-mono text-xs select-all cursor-pointer hover:bg-slate-700" onClick={() => navigator.clipboard.writeText('npm run build')}>
                              npm run build
                          </div>
                        </li>
                        <li>
                          왼쪽 파일 목록에서 <strong className="text-brand-700">dist</strong> 폴더 열기 &gt; <strong>index.html</strong> 다운로드
                        </li>
                    </ol>
                </div>
            </div>
            
            <button onClick={() => setShowGuide(false)} className="w-full bg-brand-600 text-white font-bold py-3 rounded-xl hover:bg-brand-700 shadow-lg shadow-brand-500/20">확인했습니다, 찾아볼게요!</button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 sm:p-6 lg:p-8">
        <GoogleMapLoader onLoad={() => setMapsLoaded(true)}>
          {!mapsLoaded ? (
            <div className="flex flex-col justify-center items-center h-[60vh] text-slate-400">
              <div className="w-12 h-12 border-4 border-brand-100 border-t-brand-600 rounded-full animate-spin mb-4"></div>
              <p className="text-sm font-medium animate-pulse">지도 서비스를 연결하고 있습니다...</p>
            </div>
          ) : (
            <div className="animate-fade-in-up h-full">
              {activeTab === Tab.MATCH && <MemberMatching />}
              {activeTab === Tab.UPLOAD && <LeaderUpload />}
              {activeTab === Tab.DASHBOARD && <Dashboard />}
            </div>
          )}
        </GoogleMapLoader>
      </main>

      <footer className="border-t border-slate-200 bg-white mt-auto py-6">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-xs text-slate-400 font-medium">
            &copy; {new Date().getFullYear()} Church Small Group Manager. Powered by Google Sheets & Maps.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;