export interface Leader {
  id?: number;
  name: string;
  role: string;    // 직분 (예: 집사, 권사, 성도)
  gender: 'Male' | 'Female' | 'Other';
  age: number;     // 나이
  contact: string; // 연락처
  address: string;
  lat: number;
  lng: number;
  max_capacity: number;
  current_members: number;
}

export interface Member {
  id?: number;
  leader_id: number | null;
  name: string;
  role: string;    // 직분
  age: number;     // 나이
  contact: string; // 연락처
  address: string;
  lat: number;
  lng: number;
  leader?: Leader; // For Joined queries
}

export interface GeocodeResult {
  lat: number;
  lng: number;
  formattedAddress: string;
}

export interface ScoredLeader extends Leader {
  distance: number; // in km
  ageDiff: number;  // age difference
  score: number;    // lower is better (combined metric)
}

// Declare globals for Google Maps only
declare global {
  interface Window {
    google: any;
    initMap?: () => void;
    gm_authFailure?: () => void;
  }
}