import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const rootElement = document.getElementById('root');

if (!rootElement) {
  // Fallback if root is missing (unlikely in this setup)
  document.body.innerHTML = '<div style="color:red; padding:20px;">Critical Error: Cannot find #root element.</div>';
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);

try {
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} catch (error: any) {
  // Catch render errors (like module resolution failures in some envs)
  console.error("Application Render Failed:", error);
  rootElement.innerHTML = `
    <div style="padding: 2rem; color: #dc2626; background: #fee2e2; border: 1px solid #fca5a5; margin: 2rem; border-radius: 0.5rem;">
      <h2 style="font-weight: bold; font-size: 1.5rem; margin-bottom: 1rem;">앱 실행 오류</h2>
      <p>애플리케이션을 시작하는 도중 문제가 발생했습니다.</p>
      <pre style="margin-top: 1rem; padding: 1rem; background: rgba(0,0,0,0.05); overflow-x: auto; font-size: 0.875rem;">${error?.message || JSON.stringify(error)}</pre>
      <p style="margin-top: 1rem; font-size: 0.875rem; color: #7f1d1d;">개발자 도구(F12)의 콘솔(Console) 탭을 확인해주세요.</p>
    </div>
  `;
}