// IMPORTANT: Replace these with your actual keys
// If you see 'RefererNotAllowedMapError', go to Google Cloud Console > Credentials > API Key
// and add your current URL to 'Website restrictions'.
export const GOOGLE_MAPS_API_KEY = 'AIzaSyAnGr22LerGTOWJ7FMsGoG8cVUtHwcbICw';

export const SHEET_API_URL_KEY = 'CHURCH_GROUP_SHEET_URL';

// Geocoding request interval to avoid OVER_QUERY_LIMIT (ms)
export const GEOCODE_DELAY_MS = 250;