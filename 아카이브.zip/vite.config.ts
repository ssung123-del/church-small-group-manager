import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { viteSingleFile } from "vite-plugin-singlefile"

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), viteSingleFile()],
  build: {
    outDir: 'dist', 
    // cssCodeSplit: false, // (Optional) CSS splitting is handled by singleFile plugin
    assetsInlineLimit: 100000000, // Ensure all assets are inlined
    chunkSizeWarningLimit: 100000000, // Suppress size warnings for the single file
  }
})